# Theme — one flat token set, all from the compose block

`theme({ … })` sets the page's look: cards, controls and charts read the
same tokens. Pass the camelCase key, the runtime sets the `--kebab-case`
CSS token; every key is optional; the defaults are the BNP Paribas brief (green on
white, warm greys, square corners, a green header band, Open Sans or
Arial) with a dark variant under `prefers-color-scheme: dark`. Never edit `<head>` or the stylesheet for a theme: the
compose block holds the whole look.

| Group | Keys |
|---|---|
| Colours | `color1`…`color8` (chart series), `primary`, `onPrimary`, `bg`, `pageBackground` (any CSS background: gradient, image), `surface`, `cardBg`, `kpiBg`, `chartBg`, `tableBg`, `filterBg`, `text`, `muted`, `subtle` (axis labels, placeholders), `headingColor`, `kpiColor`, `border`, `borderStrong`, `grid`, `surface2`, `error`, `success`, `warning`, `info`, `headerBg` + `headerColor` (set them and the header becomes a full-width brand band) |
| Type | `font`, `fontHeading`, `fontCardTitle`, `fontKpi`, `fontMono`, `sizeTitle`, `sizeHeading`, `sizeCardTitle`, `sizeBody`, `sizeCaption`, `sizeKpi`, `sizeTable`, `weightTitle` (the page title; defaults to `weightHeading`), `titleTransform` (`'uppercase'` by default, `'none'` to keep the case), `weightHeading`, `weightKpi`, `lineHeight`, `letterSpacingHeading` |
| Shape, space | `radius`, `radiusSmall`, `shadow`, `shadowHover` (defaults to `shadow` when a theme sets one), `cardBorder` (`'0'` drops card borders), `padding`, `gap`, `sectionGap`, `pageWidth`, `pagePadding`, `chartHeight` |
| Special | `fontUrl` (a stylesheet URL or a list, e.g. Google Fonts; the browser loads it), `css` (extra CSS appended to the page), `mode` (`'light'` or `'dark'`: fixes the scheme and hides the header's light/dark switch; left out, the page follows the reader's preference and offers the switch) |

`kpi`, `bar` and `line` also take `color`: `'color2'`, `'primary'` or any
CSS colour.

A design brief maps onto these keys — its accent is `primary`, its canvas
`bg`, its surfaces `cardBg`/`kpiBg`/`chartBg`/`tableBg`, its ink `text`
and `muted`, its hairline `border`, its categorical palette
`color1`…`color8`, its display and body fonts `fontHeading` and `font`,
its radii and paddings `radius`/`radiusSmall`/`padding`. Whatever it asks
for beyond the keys goes in `css`. A storybook brief, for instance:

```js
theme({ mode: 'light', fontUrl: 'https://fonts.googleapis.com/css2?family=Caveat:wght@600&family=Inter:wght@400;600&display=swap',
  font: '"Inter", sans-serif', fontHeading: '"Caveat", cursive', sizeTitle: '32px', sizeHeading: '22px',
  color1: '#4A7C59', color2: '#2D3B2A', color3: '#C3924A', color4: '#6B7A64', primary: '#4A7C59',
  bg: '#F6F1E4', cardBg: '#E8E1CF', chartBg: '#F6F1E4', text: '#2D3B2A', muted: '#6B7A64', border: 'rgba(45,59,42,0.12)',
  radius: '20px', radiusSmall: '16px', padding: '24px', sectionGap: '24px', shadow: 'none' })
```
