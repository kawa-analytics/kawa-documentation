# The request body a custom `block()` sends — read only when writing one

`block({ title, query, render })` posts `query` to `/artifact-api/query` as
it is, plus the active global filters of `query.sheetUniqueTag`, and hands
`render` the rows. The built-in primitives build these bodies for you; write
one by hand only for a shape they do not offer.

## The shape

```js
{
  sheetUniqueTag: '<sheet tag>',          // the sheet's immutable tag; a name → 400, unknown → 404

  // plain rows: select — OR grouped rows: groupBy + aggregation (never both)
  select: { columns: [ { columnName: '<column tag>', columnAlias: 'name' } ] },

  groupBy: [ '<column tag>' ],            // ['1'] for one row of totals
  aggregation: { columns: [
    { columnName: '<key tag>',   aggregationMethod: 'FIRST', columnAlias: 'key' },   // the group key reads back via FIRST
    { columnName: '<value tag>', aggregationMethod: 'SUM',   columnAlias: 'total' }, // UPPERCASE methods
  ] },

  sample: { columnName: '<the groupBy entry, same string>', sampler: 'MONTH' },     // buckets before grouping

  filters: [ { column: { columnName: '<column tag>' }, exclude: false,
               clauses: [ { operation: 'eq', arguments: { value: 'South' } } ] } ],  // AND-ed

  orderBy: { columnName: '<tag or alias>', ascending: false, useFieldName: false },
  limit: 100,                             // ALWAYS set it
  timeZone: 'Europe/Paris',               // bucketing only; default UTC
}
```

Methods: `SUM`, `AVERAGE`, `MIN`, `MAX`, `COUNT`, `COUNT_UNIQUE`, `MEDIAN`,
`FIRST`, `STD_DEV_SAMPLE`, `STD_DEV_POP`, `VAR_SAMPLE`, `VAR_POP`,
`LOWEST_QUARTILE`, `HIGHEST_QUARTILE`, `LOWEST_DECILE`, `HIGHEST_DECILE`.
Samplers: `DAY`, `WEEK`, `MONTH`, `QUARTER`, `YEAR` on dates;
`FIXED_NUMBER_OF_BINS` (`howManyBuckets`), `FIXED_SIZE_BINS` (`bucketSize`),
`LIST_OF_BINS` (`buckets`) on numbers.

## The rules that bite

- **Every column by its tag, every output with a `columnAlias`.** Without an alias the tag is the row key.
- **Every aggregation column has a method.** A bare `{ columnName }` does not return the group key: it applies the type's default (SUM on numbers → key × row count). Read a key back with `FIRST`; a sampled bucket with `MIN` (inside a bucket the members differ, so FIRST is arbitrary).
- **Filter operations by type.** text: `eq`, `ne`, `contains`, `does_not_contain`, `starts_with`, `does_not_start_with`, `ends_with`, `does_not_end_with`, `in_list` (value is an array), `empty`, `not_empty`; matching is case-insensitive and `ne` keeps NULL rows. number: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `empty`, `not_empty`. boolean: `eq`/`ne` with a real boolean, `empty`, `not_empty`. date/datetime: **only** `range` — `arguments: { dateFrom, dateTo }` in epoch days for a `date`, `{ instantMillisecondsFrom, instantMillisecondsTo }` in epoch millis for a `date_time`, either bound optional. `eq` on a temporal column silently matches every row; `gt`/`lt` → 400.
- **`sample.columnName` is the same string as the `groupBy` entry** it buckets, or the sampler is silently dropped.
- **`orderBy.columnName` is a tag or an alias that the query projects**; anything else is silently ignored (unsorted rows, an arbitrary top N).
- **`limit` always.** Omitted = 100 rows, silently. Never a negative limit in an artifact (that is every row).
- Never send `workspaceId`, `sheetName`, `datasourceId` or an `*Id` number.

## The answer

`{ columns: [...], columnsMeta: [{ key, tag, name, type }], rows: [...] }`.
Rows are keyed by alias. A NULL cell is **omitted** from its row (`row.x ?? null`);
the NULL group reads back as `''`. Dates are `'YYYY-MM-DD'`, datetimes
`'YYYY-MM-DDTHH:MM:SS'`.

## Two examples

```js
// a two-level breakdown, rendered as a heatmap grid by hand
block({ id: 'region-band', title: 'Price by region and band',
  query: { sheetUniqueTag: S, groupBy: ['_ci_region', '_ci_band'],
    aggregation: { columns: [
      { columnName: '_ci_region', aggregationMethod: 'FIRST', columnAlias: 'region' },
      { columnName: '_ci_band',   aggregationMethod: 'FIRST', columnAlias: 'band' },
      { columnName: '_ci_price',  aggregationMethod: 'SUM',   columnAlias: 'total' } ] },
    limit: 500 },
  render(rows, el, ctx) { /* el is the card body; build a grid, colour cells by total, ctx.fmt(v, 'decimal') */ } })

// price bins, drawn with the shared chart helper
block({ id: 'price-bins', title: 'Products per price bin',
  query: { sheetUniqueTag: S, groupBy: ['_ci_price'],
    sample: { columnName: '_ci_price', sampler: 'FIXED_NUMBER_OF_BINS', howManyBuckets: 6 },
    aggregation: { columns: [
      { columnName: '_ci_price', aggregationMethod: 'MIN',   columnAlias: 'lo' },
      { columnName: '_ci_price', aggregationMethod: 'MAX',   columnAlias: 'hi' },
      { columnName: '_ci_name',  aggregationMethod: 'COUNT', columnAlias: 'n' } ] },
    orderBy: { columnName: 'lo', ascending: true, useFieldName: false }, limit: 50 },
  render(rows, el, ctx) {
    ctx.chart('bar', rows.map(r => `${ctx.fmt(r.lo, 'decimal')}–${ctx.fmt(r.hi, 'decimal')}`),
                     [{ label: 'Products', data: rows.map(r => Number(r.n)) }])
  } })
```

`render` runs again on every refresh and filter change with fresh rows;
`el` keeps whatever you appended, so replace its content rather than append.
Keep the DOM small: at most 100 rows or 50 bars from one body — aggregate
or cap on the server, never render a result whole.
