# Editing an existing artifact

The user hands you an HTML file instead of a paste. Read its first 8
lines, nothing more yet.

**Built from this starter.** Line 6 reads
`<script type="text/kawa-compose" id="compose">`: the compose block
starts on line 7 and runs to the first `</script>`; read it (it is short)
and it is the whole artifact. Edit it with your editor's replace tool,
leave everything else alone. An older build (runtime 1.0–1.2) has no
block at the top but `<script id="kawa-lite"` further down and its
compose block as the last `<script id="compose">` before `</body>`: find
it with your editor's search (or read the file's last 40 lines), edit it
there. The runtime's version is `data-version` on `<script id="kawa-lite"`;
when the user asks for something that runtime lacks (`CHANGELOG.md` says
what each version added), copy `starter.html` afresh and move the compose
block onto its line 7 instead of patching the runtime.

**Any other HTML artifact.** Read it once, then make the smallest edit
that does what was asked, as targeted replacements, never a rewrite. Keep
its auth gate, its ids and its way of addressing columns: a page that
names columns by display name keeps doing so in the logic you touch; only
a new query uses tags. Do not restyle, rename or clean up what was not
asked. If the change needs a structure the page lacks (a new chart kind,
a layout, filters), say so and offer to rebuild it on the starter: the
sheet and column tags are in its request bodies, the column types come
from the user.

Hand over as in SKILL.md; the user uploads the file as a **new version of
the same artifact**, in the same workspace.
