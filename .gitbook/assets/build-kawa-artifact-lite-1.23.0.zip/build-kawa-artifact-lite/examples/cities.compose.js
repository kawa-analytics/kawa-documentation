const CITIES = 'cities_doccanon001'
page({ title: 'Cities at a Glance', subtitle: 'Live from the Cities sheet' })
filter({ id: 'city', type: 'text', columns: { [CITIES]: '_ci_city' } })
layout(`
  <div class="row cols-2" id="figures"></div>
  <div class="row cols-2"><div id="chart"></div><div id="share"></div></div>
  <div id="rows"></div>`)
kpi({ id: 'total-population', into: 'figures', sheet: CITIES, column: '_ci_population', method: 'SUM', compact: true })
kpi({ id: 'city-count', into: 'figures', sheet: CITIES, column: '_ci_city', method: 'COUNT_UNIQUE', label: 'Cities' })
bar({ id: 'population-by-city', into: 'chart', sheet: CITIES, groupBy: '_ci_city', value: '_ci_population', method: 'SUM', top: 20 })
pie({ id: 'area-share', into: 'share', sheet: CITIES, groupBy: '_ci_city', value: '_ci_area', method: 'SUM', label: 'Area share' })
table({ id: 'cities', into: 'rows', sheet: CITIES, label: 'Cities',
  columns: [ { tag: '_ci_city', type: 'text' }, { tag: '_ci_population', type: 'integer' } ],
  orderBy: { column: '_ci_population', ascending: false },
  detail: { key: '_ci_city', columns: [ { tag: '_ci_area', label: 'Area (km²)', type: 'decimal', decimals: 1 } ] } })
