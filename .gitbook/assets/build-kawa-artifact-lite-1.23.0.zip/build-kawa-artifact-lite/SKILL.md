---
name: build-kawa-artifact-lite
description: Build a read-only KAWA HTML artifact (KPIs, charts, tables with row details, filters) over one or several sheets WITHOUT talking to KAWA, in as few tokens as possible, no shell needed. Use when the user pastes sheet immutable tags with column tags and types and wants a dashboard or data view, or hands over such an artifact to edit. Not for writes, workflows or generated text - that is build-kawa-artifact.
license: MIT
metadata:
  author: kawa
  category: artifacts
  audience: coding-agents
  version: "1.23.0"
---

# build-kawa-artifact-lite

No KAWA access, no CLI, no browser, no shell. One copy, one edit; the page
runs its own queries on KAWA's backend.

## 1 · Read the paste

Its shape varies but it always carries each sheet's **immutable tag** and,
per column, its **tag**, **type** and **name**. Types: `text`, `integer`,
`decimal`, `boolean`, `date`, `date_time`. Tags are opaque: copy them
verbatim, never guess or derive one. A fact you cannot find → ask.

```
sheet cities_doccanon001 "Cities"
_ci_city text "City" · _ci_population integer "Population" · _ci_area decimal "Area (km²)"
```

## 2 · Copy, then replace one line

1. Copy `starter.html` to `<name>.html` (`cp` or `Copy-Item`). Never edit
   `starter.html` itself.
2. Read lines 1–8 of the copy; line 7 is `// COMPOSE: …`, inside
   `<script type="text/kawa-compose" id="compose">`. Replace that one line
   with your compose block (your editor's replace tool). Nothing else is
   edited: the runtime below (do not read it) builds, runs and
   renders everything, with loading / error / data per block.
3. The editor's success is the check. Do not read the file back.

What replaces the line, for the paste above:

```js
const CITIES = 'cities_doccanon001'
page({ title: 'Cities at a Glance', subtitle: 'Live from the Cities sheet' })
filter({ id: 'city', type: 'text', columns: { [CITIES]: '_ci_city' } })
layout(`
  <div class="row cols-2" id="figures"></div>
  <div class="row cols-2"><div id="chart"></div><div id="share"></div></div>
  <div id="rows"></div>`)
kpi({ id: 'total-population', into: 'figures', sheet: CITIES, column: '_ci_population', method: 'SUM', compact: true })
kpi({ id: 'city-count', into: 'figures', sheet: CITIES, column: '_ci_city', method: 'COUNT_UNIQUE', label: 'Cities' })
bar({ id: 'population-by-city', into: 'chart', sheet: CITIES, groupBy: '_ci_city', value: '_ci_population', method: 'SUM', top: 20 })
pie({ id: 'area-share', into: 'share', sheet: CITIES, groupBy: '_ci_city', value: '_ci_area', method: 'SUM', label: 'Area share' })
table({ id: 'cities', into: 'rows', sheet: CITIES, label: 'Cities',
  columns: [ { tag: '_ci_city', type: 'text' }, { tag: '_ci_population', type: 'integer' } ],
  orderBy: { column: '_ci_population', ascending: false },
  detail: { key: '_ci_city', columns: [ { tag: '_ci_area', label: 'Area (km²)', type: 'decimal', decimals: 1 } ] } })
```

## The primitives

`sheet` and every column option (`column`, `groupBy`, `value`, `date`,
`series`, `key`, `tag`) are tags from the paste. Every block takes `id`
(stable, kebab-case), `into` (a layout area) and `filters` (block-level,
below); `kpi`, `bar` and `line` also `color` (`'color2'`, `'primary'`, any
CSS colour). `label` is optional everywhere: a block or column without one
is named from its tags (`_ci_order-date` → Order date, SUM of `_ci_sales`
by `_ci_state` → Sales by State); write it when the paste's name differs.

- `page({ title, subtitle, refresh })` — `refresh`: seconds between automatic reloads
- `layout(html)` — the page skeleton; its empty `<div id="…">` are areas.
  Classes: `row` (auto-fit), `cols-1`…`cols-4`, `span-2`, `span-3`,
  `span-full`, `stack`; plain `h2`/`p`. With a layout every block needs
  `into` (an unknown id paints an error card); without one, blocks follow
  call order, KPIs on one row, a grid below.
- `filter({ id, label, type, columns: { '<sheet-tag>': '<column-tag>', … } })` —
  global, options from the sheet, applies to the blocks of the listed
  sheets only. Control by `type`: text/boolean a select, integer/decimal
  min–max, date/date_time from–to.
- `kpi({ sheet, column, method, label, decimals, compact, prefix, suffix })`
- `bar({ sheet, groupBy, value, method, label, top (20, max 50), sort: 'key', series (a second tag → stacked) })`
- `pie({ sheet, groupBy, value, method, label, top })`
- `line({ sheet, date, sampler: DAY | WEEK | MONTH | QUARTER | YEAR, value, method, label, series, timeZone })`
- `table({ sheet, label, columns: [{ tag, label, type, decimals, pill }], orderBy: { column, ascending }, limit (rows at most, 2000), pageSize (20), height, columnFilters (true), search: '<text tag>', groupBy: [tags] (non-key columns then need method), detail })`
  — a paged grid: one query brings up to `limit` rows (KAWA-sorted by
  `orderBy`); pages, sorts, header filters and the Total row happen in the
  browser; the badge and the status say how much of the whole set is loaded;
  short categorical columns read as pills (`pill: false` opts out).
  — `detail: { key, columns, sheet, column, limit (20, max 100), title, filters, render }`:
  a click on a row opens a modal with the rows whose `key` column equals
  the row's value (`key` may be a column not shown); `sheet` + `column`
  read them from another sheet.
- `block({ title, query, render(rows, el, ctx) })` — a raw body and your
  own rendering, only when nothing above fits: read
  `references/query-dsl.md` first.
- `theme({ … })` — leave it out for the default (the BNP Paribas look);
  for a brand, a palette or a design brief read `references/theme.md`.
  Never edit `<head>` or the stylesheet.

Interactive with no configuration: a click on a bar or slice filters the
other blocks of its sheet (chips, Reset), cards expand and download, a
row opens a modal, nothing moves on a filter. A date filter gets quick
ranges (30/90 days, 12 months, up to the data's last date); every KPI on
its sheet gets a sparkline and, under a range, its change vs the previous
period (else its share of the whole); what `top` cuts folds into Other.

`method`: `SUM` `AVERAGE` `MIN` `MAX` `COUNT` `COUNT_UNIQUE` `MEDIAN`.
Block `filters`: `[{ column, op, value }]`, plus `type` when not text —
text ops `eq` `ne` `contains` `starts_with` `ends_with` `in_list` (array);
integer/decimal `eq` `ne` `gt` `gte` `lt` `lte`; boolean `eq`; date and
date_time: `{ column, type, from, to }` (ISO, either bound optional);
`empty` / `not_empty` on any type. Search and filters re-query KAWA;
nothing is computed or joined in the browser — a figure across two sheets
needs a sheet in KAWA that has it: say so.

## 3 · Hand over

A few lines: the file's path, the tags it binds, and that it is untested
until it paints. The user uploads it in KAWA as a new HTML artifact (or a
new version), **in the workspace that owns the sheets** — elsewhere every
query fails with 404 — and checks that every block paints.
A failing block shows the server's answer in its card; pasted back here,
it says what to fix.

## Rules

- Tags come from the paste, verbatim. No tag → ask.
- A file handed over instead of a paste: read `references/editing.md`
  (built from this starter → edit its compose block only; anything else
  → the smallest in-place edit).
- The runtime's `fetch` to `/artifact-api/query` is the page's only call
  to KAWA: never a host, never a key, never another call. Do not read or
  edit the runtime; keep its caps (2,000 rows a table, 50 bars a chart).
