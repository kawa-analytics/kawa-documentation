# Changelog — build-kawa-artifact-lite

## 1.23.0 — 2026-11-07
- Fix: the header filter button of the grid had the page's button padding, so its icon overflowed its box and AG's hover halo and active dot were drawn beside it (a tinted block up-left of the icon, a dot floating away from it). The button is 16px again; an active filter shows the icon in the primary colour with the dot at its corner, hover a soft round halo and the text colour, through AG's own theme parameters (no `!important`).

## 1.22.0 — 2026-11-07
- Fix: two changes in quick succession started two loads of a block and the slower, stale answer could paint last. A block now runs one load at a time; a change during a load queues one more run on the latest filters.

## 1.21.0 — 2026-11-07
- A reload of a grid (Refresh, `page({ refresh })`, a filter change) keeps the reader on their page; only Reset returns to the first.

## 1.20.0 — 2026-11-07
- Keyboard: a doughnut legend entry answers Enter and Space like a click; expanding a card by keyboard keeps the focus in the overlay (the move had blurred the button), so Tab cycles inside and Escape returns it.

## 1.19.0 — 2026-11-07
- Vertical bars print their figure above each bar and a stacked chart the total of each stack (twelve categories or fewer; hidden series left out).

## 1.18.0 — 2026-11-07
- `label` is optional everywhere: a KPI, bar, pie, line, filter or grid column without one is named from its tags and method (`Population`, `Distinct City`, `Sales by State`, `Sales per month, by Segment`, `Order date`); a name declared once on the page (a filter's, a column's) is reused. The worked example and SKILL.md drop the labels the names cover.

## 1.17.0 — 2026-11-07
- Keyboard: a KPI figure is a control (Tab reaches it, Enter or Space copies it, a visible ring); the × of a chip has a ring. A loading grid shows ten skeleton rows. The mode switch and the paging panel do not print. An empty grid says it once (the status reads `0 rows`, the grid's overlay says the rest).

## 1.16.0 — 2026-11-07
- A single line rings its peak with the value above it; single-series bars (four or more) carry a dashed mean line labelled `avg …`, Other left out; a bar's tooltip adds its share of the total, a single line's tooltip the change against the bucket before; a pulsing dot marks a page that refreshes itself; dark cards catch the light on their top edge.

## 1.15.0 — 2026-11-07
- Grid: numeric cells are right-aligned again (the class for negative figures had replaced the alignment class); row hover is a primary tint; the Total row reads as a footer; a firmer rule under the header; a 2px bar under each positive figure shows its share of the column's largest (`bars: false` on a column opts out); no focus box on a clicked cell; tabular numerals in date inputs.

## 1.14.0 — 2026-11-07
- KPI figures read with quiet units: prefix, compact unit and suffix are small and muted beside the number; the line under a KPI shows the months its sparkline spans when nothing is filtered; the pointer over a sparkline reads a month and its figure on that line; the tile's primary wash shows (it was overridden).
- Charts: a hairline between stacked segments, ranked bars on a faint track to the plot's edge, a thinner doughnut ring, a legend entry under the pointer fades the other series; cards arrive in a short cascade on first paint.
- Grid: tabular numerals, a muted paging panel, and an active header filter marks its icon in the primary colour instead of a tinted block.

## 1.13.0 — 2026-11-07
- The grid is a plain paged grid: one query brings up to `limit` rows (KAWA-sorted by `orderBy`); the grid pages (`pageSize`, default 20, a 10/20/50/100 picker), sorts and header-filters them in the browser; a one-row COUNT gives the badge and the status the size of the whole set; the Total row sums the loaded rows that pass the grid filters (`Total (loaded)` when the set was cut). No infinite scrolling: rows vanished on scroll.
- Fix: a chart expanded then collapsed kept its full-screen size. The canvas is absolute in its box, chart wraps have a floor and grow with their card, expand and collapse resize the chart.
- Fix: two cards in one row ended at different heights; a layout host stretches its card to the row.
- The expand button shows a collapse icon while the card is full screen; the light/dark switch is the height of Refresh and borderless until hovered.
- Fix: a tooltip left behind by a scroll could widen the page; the status line under a grid always shows (`184 rows`), so a filter that leaves fewer rows never shortens the card; the date filter wraps on a phone; a KPI sparkline shrinks with a narrow tile.

## 1.12.0 — 2026-11-07
- A light/dark switch in the header when the theme leaves `mode` out: the tokens flip and every chart, sparkline and grid repaints in place, no reload, no query. `theme({ mode })` now also applies the dark defaults for whatever it leaves unset, and hides the switch.

## 1.11.0 — 2026-11-07
- A plain grid asks KAWA for the whole filtered set's row count and the sums of its numeric columns (one one-row query per refresh): the status reads `100 of 4,912 rows loaded · scroll for more`, the count badge shows the true total, and a Total row is pinned under the grid.

## 1.10.1 — 2026-11-07
- Fix: the Other footnote sits under its chart, not above it; Reset also clears every grid's header filters, sort and search box.

## 1.10.0 — 2026-11-07
- Bars and doughnuts over a sum or a count fold the categories past `top` into Other (one extra one-row query, only when the server cut): a grey slice so shares add up, a grey bar when it does not dwarf the shown ones, a footnote under the chart otherwise; Other is never selectable. `others: false` turns it off.

## 1.9.1 — 2026-11-07
- Docs: the worked example drops two options the grid no longer has (`pageSize`, an explicit `columnFilters`); SKILL.md names the BNP default where it described a neutral one.

## 1.9.0 — 2026-11-07
- Usability: a KPI value copies to the clipboard on click (a small toast confirms), the grid keeps keyboard reach (cell focus, Enter on a row opens its detail), the error banner offers "Retry failed" for every failed block at once, Tab stays inside an open modal or expanded card and focus returns on close, the header's clock reads on the band.

## 1.8.0 — 2026-11-07
- Date filters carry quick ranges beside their inputs — All, 30 days, 90 days, 12 months — anchored on the last date the data holds (one MIN/MAX query at start), so historical data gets meaningful presets.
- Every KPI on a sheet that has a date filter shows a sparkline of its last twelve months (in its own colour) and, when a date range is set, its change against the previous period of the same length (`▲ 12.4% vs previous period`); without a range it keeps its share of the unfiltered figure.
- A single line ends on a dot with its last value.
- The filter bar is a frosted strip under the header; doughnut legends stack under narrow charts in columns that keep their names; focus returns to the trigger when a modal or an expanded card closes.

## 1.7.0 — 2026-11-07
- The table is AG Grid (community, from jsDelivr, loaded only when a page has a table), themed from the tokens through its theming API: header sort and header filters are sent to KAWA (orderBy and clauses) through an infinite datasource, rows arrive in blocks of 100 as the user scrolls up to `limit` (2,000 at most), short categorical columns read as pills, negatives in the error colour, dates in the reader's locale. The pager and the rows-to-load selector are gone.
- A row's detail opens in a modal (title, the key as subtitle, label/value pairs or a small table), no longer as an expanded row.
- Defaults are the BNP Paribas brief: green on white, the brand palette, warm grey surfaces, hairlines, square corners, no shadows, Open Sans loaded with Arial as fallback, uppercase titles (`titleTransform`), a header band in the primary colour (`headerBg: 'transparent'` for a plain header); a dark variant of the brief under `prefers-color-scheme: dark` (series colour 2 swapped for a light neutral).
- Chart tooltips are HTML elements (surface, hairline, shadow, swatches, tabular values, slice share, stacked total) and doughnut legends are lists with value and share (hover lifts the slice, click hides it); KPI tiles read label first; new tokens `subtle`, `borderStrong`, `surface2`, `titleTransform`.

## 1.6.1 — 2026-11-07
- Fix: every filter control is 32 px tall (date inputs were taller than selects and pulled their labels out of line); zebra rows a shade lighter in dark themes.
- Fix: a KPI's context line shares the label's line height, so its appearance under a filter no longer grows the tile by two pixels.

## 1.6.0 — 2026-11-07
- Finesse: drawn chevrons on every select, KPI labels as tracked small caps, a refresh icon that turns while loading, a faint tint of the primary at the top of the page (scrolls with it), content that rises in on first paint, KPIs two to a row on phones; `weightTitle` for a page title lighter or heavier than the headings.
- Tables: a user picks how many rows to load once the window is full (`Load 100 · 250 · 500 · 1000 · 2000 rows`), subtle zebra rows, a header shadow once the body scrolls, the initial sort shown on its header.
- `page({ refresh })`: a live page reloads itself every N seconds (never while a request is pending or the tab is hidden) and the clock says `· live`.
- A fourth benchmark theme, Marex Prime Dark, drove the dark-mode polish.

## 1.5.0 — 2026-11-07
- Six iterations against a two-sheet benchmark on live data, every change inside the runtime, the compose block untouched (log: a Desktop `improvements.md` with one screenshot set per iteration).
- Layout: areas are addressed by name (`data-area`), so a block with the same id as an area can no longer capture it (a bar used to land inside a KPI card); a KPI in a row never stretches; charts fill their card so side-by-side cards are level.
- Charts: long or many categories read as horizontal bars with truncated labels and the full name in the tooltip, values at the end of ranked bars, negatives in the error colour and a stronger zero line; compact axes (`80M`), time buckets as dates (`Jan 2020`, `Q1 2020`); lines with monotone interpolation, hidden points, a gradient area when single, a dashed guide and one tooltip per month; doughnuts with the total in the hole, the hovered share, percentages in the legend; one colour per category across the page, a stable legend order; themed tooltips with stacked totals; a short first-paint animation, none on refresh or under reduced motion.
- Interactivity: a click on a bar or a slice selects its category — every other block of the sheet is filtered, the source keeps its context with the rest dimmed, chips and a Reset appear in the (now sticky) filter bar, active filters are marked; card tools on hover expand a card over the page or download it (PNG / CSV).
- KPI: counts up on first paint, glides on refresh, and shows its share of the unfiltered figure (`48% of $1.1B overall`) whenever a filter or a selection narrows the page.
- States: a skeleton in the card's own shape on first load, "No data for the current filters" instead of empty axes or an empty table, a Retry on failed blocks, a failed KPI shows its title.
- Still page: nothing moves on a filter — orientation, chart height, legend side and a page of table rows are kept from the first paint (ranked bars with fewer categories stay compact at the top).
- Tables: one-line cells with an ellipsis and the full text on hover, a chevron on clickable rows, lighter underline header filters, thin scrollbars.
- Theme: `sizeTable`, `shadowHover`, `headerBg` + `headerColor` (a brand header band); card hover shade and a KPI sheen derived from the primary; print stylesheet; relative "Updated … ago" clock.

## 1.4.0 — 2026-11-07
- `table`: KAWA sorts and filters and returns `limit` rows (default 500, max 2,000 — the QueryDsl has no offset), the page shows them `pageSize` (20) at a time with a first/previous/next/last pager and a `start–end of N` range; a full window reads `N+`. The table scrolls inside `height` (default the new `tableHeight` token, 480px) under a sticky header.
- `table({ columnFilters: true })`: one filter control under each header, typed like the filter bar (text contains, number min/max, date from/to, boolean yes/no), sent to KAWA as clauses; `filter: false` on a column opts it out; a header click still sorts, typing in its filter never does.
- The filter bar and the header filters share one control builder.

## 1.3.0 — 2026-11-07
- No shell needed, nothing read but 8 lines: the compose block is now an inert `<script type="text/kawa-compose" id="compose">` at the top of `<head>` (line 7 holds the `// COMPOSE` marker), replaced with any editor's replace tool; the runtime runs it last, once every primitive exists. A compose block that does not parse, or a starter whose marker was never replaced, paints one error card instead of a blank page.
- SKILL.md halved: the primitives as signatures, the worked example inline (it is `examples/cities.compose.js`), the theme keys in `references/theme.md` and the editing flow in `references/editing.md`, each read only when needed; the Windows copy command named (`Copy-Item`).

## 1.2.1 — 2026-11-07
- Fix: a table row no longer carries the layout class `row`, which turned every row into a two-column grid of cells; layout headings and paragraphs no longer restyle content inside cards.
- Fix: nothing widens the page any more (grid areas shrink, the default grid fits a phone, a custom block's body scrolls sideways); a server error paints as one short wrapped line instead of its raw body; a single-row detail keeps each label next to its value.

## 1.2.0 — 2026-11-07
- `table({ detail: { key, columns, sheet?, column?, limit?, title?, filters?, render? } })`: a clicked row (mouse, Enter or Space) opens its detail under the row — one query on the key column's value, the detail columns shown as label/value pairs or as a small table when several rows come back; the key may be a hidden column; the detail may live on another sheet.

## 1.1.0 — 2026-11-07
- Theme: one flat token set covers what a design brief carries — per-component surfaces (`cardBg`, `kpiBg`, `chartBg`, `tableBg`, `filterBg`), `primary`/`onPrimary`, semantic colours, a typography scale (`fontHeading`, `fontKpi`, `sizeTitle`…`sizeKpi`, weights, line height), shape and spacing (`shadow`, `cardBorder`, `padding`, `sectionGap`, `pageWidth`, `chartHeight`), `pageBackground`.
- `theme()` takes `fontUrl` (web fonts), `css` (extra CSS) and `mode`, so a theme never needs an edit outside the compose block; `kpi`, `bar` and `line` take `color`.

## 1.0.0 — 2026-11-07
- First release. No KAWA access: the user pastes sheet and column tags, the agent copies `starter.html` and replaces its one `// COMPOSE` line with primitive calls, the user uploads the file.
- `starter.html` runtime: the auth gate, a flat theme (`--color-1…8`, `--font`, `--bg`, `--text`, …, set from `theme()`), the primitives `page`, `filter`, `kpi`, `bar`, `pie`, `line`, `table`, `block`, every QueryDsl body built in one place (FIRST keys, UPPERCASE methods, typed filter clauses, epoch-day / epoch-millis ranges, explicit limits), loading / error / data per block, global filters merged per sheet, server-side sort and search on tables.
- `layout(html)` + `into`: the agent writes the page's skeleton (rows, columns, spans, stacks, headings) and mounts each block in a slot; without a layout, KPIs on one row and the rest in an auto grid.
- Editing: a file built from the starter (`id="kawa-lite"`, `data-version` on the runtime) is edited through its compose block only; any other artifact gets the smallest in-place edit in its own column-addressing mode, with a rebuild on the starter offered, not imposed.
- `references/query-dsl.md`: the body shape and the rules that bite, read only for a custom `block()`.
- `examples/cities.compose.js` + `cities.html` over the Cities demo sheet; `cities.queries.json` holds the bodies the runtime sends, recorded by the jsdom test and replayed live by the standalone nightly suite.
